This pack is only for 1.21.6+

You can copy files from normal resource pack, paste them here and just remove shaders folder from assets/minecraft/shaders and it will work fine!

If you have any issues with the pack, feel free to reach out to me on Discord
Discord server: https://discord.com/invite/6JQfeQEB4W
Website: https://xqedii.dev
Private: Xqedii

Happy editing!
~ Xqedii