Hello!
As you’ve probably noticed, this resource pack contains two “assets” folders—but don’t
worry, that doesn’t mean you’ll have to spend twice as much time editing the pack.

Here’s a quick explanation. Minecraft changes how resource packs work with each update,
which is why a single pack won’t work for both version 1.8 and 1.21 at the same time.
That’s why there are two folders, and the pack.mcmeta file is configured to use one of
them based on the player’s client version.

Players using version 1.21 and above will receive the pack from the assets_1_21 folder,
while players below 1.21 will receive the pack from the regular assets folder.

These packs differ by only one file (specifically rendertype_text.json). This means you
don’t need to edit both packs—just edit one of the folders (e.g., assets) and copy it into
assets_1_21, excluding the SHADERS folder. Leaving the old shaders folder intact is important!

Once you’ve done that, the pack will work on all versions from 1.16 up to the latest!

If you have any issues with the pack, feel free to reach out to me on Discord
Discord server: https://discord.com/invite/6JQfeQEB4W
Website: https://xqedii.dev
Private: Xqedii

Happy editing!
~ Xqedii